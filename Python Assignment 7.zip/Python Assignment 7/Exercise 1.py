#importing the numpy library
import numpy as np
arr=np.arange(1,11)

#converting arr into 2x5 matrix
arr_matrix=arr.reshape(2,5)
print(arr_matrix)