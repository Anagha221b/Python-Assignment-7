#importing the numpy library
import numpy as np

arr=np.arange(1,21)

#slicing the array from 5th to 15th index
slice_arr=arr[5:16]
print(slice_arr)