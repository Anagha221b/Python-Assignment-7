#importing pandas library
import pandas as pd

#creating series with elements
fruit_series=pd.Series({'apples': 3, 'bananas': 2, 'oranges': 1})

#added new elements in the series
fruit_series['pears']=4
print(fruit_series)