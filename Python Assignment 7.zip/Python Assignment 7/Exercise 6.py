#importing pandas library
import pandas as pd

#Data with generic details
data={'Name': ['Rahul', 'Ankita', 'Risabh', 'Mukesh', 'Kavita', 'Virat',
               'Amit', 'Nitin', 'Anamika', 'Saloni'],
        'Age': [23, 35, 40, 29, 50, 36, 28, 34, 22, 41],
        'Gender': ['M', 'F', 'M', 'M', 'F', 'M', 'M', 'M', 'F', 'F']}

#creating a dataframe to display
df=pd.DataFrame(data)
#Adding a new column occupation
df['Occupation']=['Analyst','Programmer','Manager','Programmer','Manager',
                  'Analyst','Programmer','Programmer','Analyst','Manager']

#Filtering the data according to age
filter_df=df[df['Age']>=30]
print(filter_df)
