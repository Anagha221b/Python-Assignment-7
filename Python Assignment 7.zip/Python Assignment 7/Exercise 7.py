#importing pandas library
import pandas as pd

#Data with generic details
data={'Name': ['Rahul', 'Ankita', 'Risabh', 'Mukesh', 'Kavita', 'Virat',
               'Amit', 'Nitin', 'Anamika', 'Saloni'],
        'Age': [23, 35, 40, 29, 50, 36, 28, 34, 22, 41],
        'Gender': ['M', 'F', 'M', 'M', 'F', 'M', 'M', 'M', 'F', 'F']}

#creating a dataframe to display
df=pd.DataFrame(data)
#Adding a new column occupation
df['Occupation']=['Analyst','Programmer','Manager','Programmer','Manager',
                  'Analyst','Programmer','Programmer','Analyst','Manager']

#convert the dataframe into a csv file
df.to_csv('employee.csv',index=False)
#reading the csv file again 
read_df=pd.read_csv('employee.csv')
print(read_df)